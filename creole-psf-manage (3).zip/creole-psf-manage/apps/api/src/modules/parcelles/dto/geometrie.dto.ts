import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsIn, IsNumber, IsOptional, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

/**
 * Géométrie d'une parcelle. On accepte deux formes, toutes deux optionnelles :
 *   - `contour` : un polygone GeoJSON (le tracé dessiné sur la carte).
 *   - `pointGps` : un simple point lat/lng.
 *
 * GeoJsonPolygon est déclaré EN PREMIER pour éviter l'erreur
 * "Cannot access before initialization" au démarrage NestJS.
 */

/** Forme minimale d'un polygone GeoJSON, validée en surface. */
export class GeoJsonPolygon {
  @ApiProperty({ enum: ['Polygon'] })
  @IsIn(['Polygon'])
  type!: 'Polygon';

  @ApiProperty({ description: 'Anneaux de coordonnées [ [ [lng,lat], ... ] ]' })
  @IsArray()
  coordinates!: number[][][];
}

export class PointGpsDto {
  @ApiProperty({ example: 18.5944, description: 'Latitude (WGS84)' })
  @IsNumber()
  lat!: number;

  @ApiProperty({ example: -72.3074, description: 'Longitude (WGS84)' })
  @IsNumber()
  lng!: number;
}

export class GeometrieDto {
  @ApiPropertyOptional({
    description: 'Polygone GeoJSON du contour de la parcelle',
    example: {
      type: 'Polygon',
      coordinates: [[[-72.30, 18.59], [-72.29, 18.59], [-72.29, 18.60], [-72.30, 18.60], [-72.30, 18.59]]],
    },
  })
  @IsOptional()
  contour?: GeoJsonPolygon;

  @ApiPropertyOptional({ type: PointGpsDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => PointGpsDto)
  pointGps?: PointGpsDto;
}
