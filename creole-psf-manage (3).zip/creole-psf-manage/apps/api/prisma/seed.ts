/**
 * Seed minimal — module Authentification.
 * Utilise bcryptjs (pas de compilation native, fonctionne dans tous les
 * environnements dont GitHub Codespaces).
 */
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const ROLES_SYSTEME = [
  'Super Administrateur',
  'Administrateur',
  'Gestionnaire',
  'Agronome',
  'Comptable',
  "Chef d'équipe",
  'Employé',
  'Visiteur',
] as const;

const PERMISSIONS_MODULE_AUTH = [
  { code: 'auth.sessions.voir', module: 'auth', description: 'Voir ses propres sessions actives' },
  { code: 'utilisateurs.gerer', module: 'auth', description: 'Créer/modifier/désactiver des utilisateurs' },
  { code: 'roles.gerer', module: 'auth', description: 'Créer/modifier des rôles personnalisés' },
  { code: 'permissions.gerer', module: 'auth', description: 'Assigner des permissions à un rôle' },
] as const;

async function main() {
  console.log('Seed — permissions du module Authentification...');
  for (const permission of PERMISSIONS_MODULE_AUTH) {
    await prisma.permission.upsert({
      where: { code: permission.code },
      update: {},
      create: permission,
    });
  }

  console.log('Seed — rôles système...');
  for (const nomRole of ROLES_SYSTEME) {
    await prisma.role.upsert({
      where: { fermeId_nom: { fermeId: null as any, nom: nomRole } },
      update: {},
      create: { nom: nomRole, estSysteme: true, fermeId: null },
    });
  }

  const superAdminRole = await prisma.role.findFirstOrThrow({
    where: { nom: 'Super Administrateur', estSysteme: true },
  });

  console.log('Seed — permissions Super Administrateur...');
  const toutesPermissions = await prisma.permission.findMany();
  for (const permission of toutesPermissions) {
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: superAdminRole.id, permissionId: permission.id } },
      update: {},
      create: { roleId: superAdminRole.id, permissionId: permission.id },
    });
  }

  console.log('Seed — ferme de démonstration...');
  const ferme = await prisma.ferme.upsert({
    where: { code: 'FERME-DEMO' },
    update: {},
    create: { nom: 'Ferme Créole Démo', code: 'FERME-DEMO', ville: 'Port-au-Prince', pays: 'Haïti' },
  });

  const email = process.env.SEED_ADMIN_EMAIL ?? 'admin@creolepsf.ht';
  const motDePasse = process.env.SEED_ADMIN_PASSWORD ?? 'ChangeMoi123!';

  console.log(`Seed — compte administrateur (${email})...`);
  const motDePasseHash = await bcrypt.hash(motDePasse, 10);

  const utilisateur = await prisma.utilisateur.upsert({
    where: { email },
    update: {},
    create: { email, motDePasseHash, prenom: 'Admin', nom: 'Démo', statut: 'ACTIF' },
  });

  await prisma.fermeUtilisateur.upsert({
    where: { fermeId_utilisateurId: { fermeId: ferme.id, utilisateurId: utilisateur.id } },
    update: {},
    create: { fermeId: ferme.id, utilisateurId: utilisateur.id, roleId: superAdminRole.id, statut: 'ACCEPTEE' },
  });

  console.log('✅ Seed terminé.');
  console.log(`   Ferme       : ${ferme.nom} (${ferme.code})`);
  console.log(`   Utilisateur : ${email} / ${motDePasse}`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
