# Tests — Creole PSF Manage

La suite couvre quatre couches. Les tests **unitaires** (backend et frontend)
tournent sans base de données. Les tests **e2e** et **base de données** exigent
une base PostgreSQL de test.

---

## 1. Installer les dépendances de test

Les outils de test ont été ajoutés aux `package.json` mais doivent être
installés (impossible ici, pas de réseau) :

```bash
# Backend
cd apps/api && npm install

# Frontend
cd apps/web && npm install
```

---

## 2. Backend — tests unitaires (aucune base requise)

Services isolés avec Prisma mocké. C'est ici que sont verrouillées les règles
métier et l'isolation multi-tenant.

```bash
cd apps/api
npm test              # lance tous les *.spec.ts
npm run test:watch    # mode veille
npm run test:cov      # avec couverture (dossier coverage/)
```

Ce qui est couvert :
- `activites.helpers.spec.ts` — calcul « en retard » (fonction pure).
- `activites.service.spec.ts` — construction des filtres, isolation par
  `fermeId`, pagination, affectation/déduplication des employés, et le correctif
  de revue (le filtre `statut` explicite n'est plus écrasé par `enRetard`).
- `entity-file-storage.spec.ts` — stockage de fichiers factorisé : validation
  format/taille, écriture disque, chemin relatif persisté.
- `cultures.service.spec.ts` — protection de suppression (refus si récoltes
  liées).
- `prisma-exception.filter.spec.ts` — filet de sécurité global : mapping des
  erreurs Prisma (P2002 → 409, P2025 → 404, P2003 → 409, inconnu → 500) sans
  fuite de détail interne.
- `create-activite.dto.spec.ts` — règles de validation des DTO (champs requis,
  énumérations, dates, et la borne `@Min(0)` sur le coût).

---

## 3. Frontend — tests unitaires (aucune base requise)

Logique et composants React avec `next/jest` + Testing Library (jsdom).

```bash
cd apps/web
npm test
npm run test:watch
```

Ce qui est couvert :
- `activites-types.test.ts` — complétude des libellés/couleurs (aucune valeur
  d'enum sans affichage).
- `badges.test.tsx` — rendu des badges (statut, priorité, type, retard).
- `use-activites-list.test.ts` — hook de liste : appel au montage, rechargement
  sur filtre, anti-rebond de la recherche (fetch mocké).

---

## 4. Base de test PostgreSQL (pour e2e + base de données)

Créez une base dédiée et exportez son URL, puis appliquez les migrations.

```bash
# Exemple avec Docker
docker run --name psf-test-db -e POSTGRES_PASSWORD=test \
  -e POSTGRES_DB=creole_psf_test -p 5433:5432 -d postgres:16

export DATABASE_URL="postgresql://postgres:test@localhost:5433/creole_psf_test?schema=public"

cd apps/api
npx prisma migrate deploy   # applique le schéma sur la base de test
```

> La base de test doit rester **séparée** de la base de développement : les
> tests créent et suppriment des données.

---

## 5. Backend — tests e2e (base requise)

Démarre l'application NestJS complète et frappe l'API via HTTP.

```bash
cd apps/api
npm run test:e2e
```

Ce qui est couvert :
- `security.e2e-spec.ts` — le guard JWT global protège toutes les routes non
  `@Public` : chaque route protégée répond `401` sans jeton.

---

## 6. Base de données — tests d'intégration (base requise)

Garanties structurelles appliquées par PostgreSQL, via Prisma direct. Exécutés
par la même commande e2e (fichiers `*.e2e-spec.ts`) :

```bash
cd apps/api
npm run test:e2e
```

Ce qui est couvert (`database.e2e-spec.ts`) :
- Contrainte d'unicité `[fermeId, numeroSerie]` sur les équipements (code
  `P2002`).
- Cascade : supprimer une activité supprime ses employés affectés et ses
  commentaires — mais pas les employés eux-mêmes.
- `SetNull` : supprimer une parcelle dénoue le lien sur les activités (la
  parcelle passe à `null`, l'activité survit).

---

## Récapitulatif des commandes

| Couche              | Commande                        | Base requise |
|---------------------|---------------------------------|:------------:|
| Backend unitaire    | `cd apps/api && npm test`       | Non          |
| Frontend unitaire   | `cd apps/web && npm test`       | Non          |
| API (e2e)           | `cd apps/api && npm run test:e2e` | Oui        |
| Base de données     | `cd apps/api && npm run test:e2e` | Oui        |

## Note d'honnêteté

Ces tests n'ont pas pu être exécutés dans l'environnement de génération (pas de
réseau ni de base). Ils sont écrits pour être exacts vis-à-vis du code et du
schéma actuels ; après `npm install`, les tests unitaires doivent passer
directement, et les tests e2e/DB après avoir pointé `DATABASE_URL` sur une base
de test migrée.
