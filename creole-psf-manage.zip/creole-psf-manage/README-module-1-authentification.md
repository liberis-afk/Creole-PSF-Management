# Creole PSF Manage — Module 1 : Authentification

Ce livrable contient **uniquement** le module d'authentification (backend NestJS + frontend Next.js), conformément au périmètre demandé.

## Ce qui est inclus

**Backend (`apps/api`)**
- Connexion (`POST /auth/login`) avec gestion du cas multi-fermes
- Sélection de ferme (`POST /auth/select-farm`)
- Rafraîchissement de token avec rotation (`POST /auth/refresh`)
- Déconnexion avec révocation de session (`POST /auth/logout`)
- Profil + permissions (`GET /auth/me`)
- Sessions actives (`GET /auth/sessions`, protégé par permission)
- JWT à 3 niveaux (access / refresh / pre-auth), secrets distincts
- RBAC dynamique : `PermissionsGuard` + décorateur `@RequirePermissions()`
- Protection des routes : `JwtAuthGuard` global + `@Public()` pour les exceptions
- Journal de sécurité (connexions, échecs, déconnexions)
- Swagger sur `/api/docs`

**Frontend (`apps/web`)**
- Page de connexion (avec sélecteur de ferme si multi-fermes)
- Déconnexion
- Architecture BFF : tokens en cookies `httpOnly`, jamais exposés au navigateur
- Middleware de protection des routes
- Layout protégé affichant le profil, page dashboard minimale (placeholder Module 2)

## Prérequis

- Node.js 20+
- Docker (pour PostgreSQL + PostGIS)

## Démarrage

### 1. Base de données
```bash
docker compose up -d
```

### 2. Backend
```bash
cd apps/api
cp .env.example .env          # ajustez les secrets JWT
npm install
npm run prisma:generate
npm run prisma:migrate        # crée les tables
npm run prisma:seed           # crée rôles, permissions, ferme + compte démo
npm run start:dev
```
API : http://localhost:3001/api/v1 — Swagger : http://localhost:3001/api/docs

### 3. Frontend
```bash
cd apps/web
cp .env.example .env.local     # JWT_ACCESS_SECRET doit être IDENTIQUE au backend
npm install
npm run dev
```
Web : http://localhost:3000

### Compte de démonstration
```
admin@creolepsf.ht / ChangeMoi123!
```

## Test rapide de bout en bout

1. Ouvrir http://localhost:3000 → redirection automatique vers `/login` (middleware).
2. Se connecter avec le compte démo → redirection vers `/dashboard`.
3. Le dashboard affiche le nom, le rôle et les permissions actives.
4. Cliquer « Se déconnecter » → retour à `/login`, cookies effacés.
5. Tenter d'accéder directement à `/dashboard` sans session → redirection `/login`.

## Hors périmètre de ce module (prochaines briques logiques)

Ces fonctionnalités de la SFD Module 1 ne sont **pas** incluses ici, volontairement, pour garder l'étape focalisée :

- **Mot de passe oublié / réinitialisation** — nécessite un service d'envoi d'email (à décider : SMTP, service tiers).
- **2FA (TOTP)** — le schéma de base de données le prévoit déjà (`deuxFAActif`, `deuxFASecretChiffre`) ; il reste à implémenter l'enrôlement et la vérification.
- **TenancyGuard** — l'isolation des futures routes `/fermes/{fermeId}/...` (le token porte déjà `fermeId`, le garde reste à écrire au moment du premier module métier).
- **Historique des connexions (vue UI)** — les données sont journalisées (`journal_securite`), l'écran de consultation viendra avec le Module 17 (Paramètres).
- **Rafraîchissement silencieux côté serveur** — le client actuel gère le 401 simplement ; la mécanique complète de refresh transparent sera ajoutée quand les modules métier consommeront l'API.
