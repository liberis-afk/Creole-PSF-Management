'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Sprout, X } from 'lucide-react';
import { NAVIGATION } from '@/lib/navigation';
import { useSidebar } from './sidebar-provider';

/**
 * Sidebar unique servant les deux contextes :
 *   - Desktop (lg+) : colonne fixe, largeur pilotée par `collapsed`.
 *   - Mobile (<lg) : tiroir translaté hors écran, révélé par `mobileOpen`,
 *     avec overlay cliquable (rendu dans AppShell).
 *
 * Les libellés disparaissent en mode replié desktop (icônes seules), mais
 * restent toujours visibles en tiroir mobile — d'où la distinction
 * `masquerLibelles` ci-dessous, qui ne s'applique QU'À desktop.
 */
export function Sidebar() {
  const pathname = usePathname();
  const { collapsed, mobileOpen, closeMobile } = useSidebar();

  const masquerLibellesDesktop = collapsed;

  return (
    <aside
      className={[
        'fixed inset-y-0 left-0 z-40 flex flex-col border-r bg-white transition-all duration-200',
        'border-gray-200 dark:border-gray-800 dark:bg-gray-950',
        // Largeur desktop selon repli
        collapsed ? 'lg:w-16' : 'lg:w-64',
        // Position : toujours visible en desktop, translaté en mobile
        'w-64 lg:translate-x-0',
        mobileOpen ? 'translate-x-0' : '-translate-x-full',
      ].join(' ')}
      aria-label="Navigation principale"
    >
      {/* En-tête / logo */}
      <div className="flex h-14 items-center gap-2 border-b border-gray-200 px-4 dark:border-gray-800">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-600">
          <Sprout className="h-5 w-5 text-white" />
        </div>
        {!masquerLibellesDesktop && (
          <span className="truncate text-sm font-semibold text-gray-900 dark:text-white">
            Creole PSF
          </span>
        )}
        {/* Fermeture du tiroir, mobile uniquement */}
        <button
          onClick={closeMobile}
          className="ml-auto rounded-md p-1 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 lg:hidden"
          aria-label="Fermer le menu"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Liens de navigation */}
      <nav className="flex-1 overflow-y-auto px-2 py-3">
        {NAVIGATION.map((section, index) => (
          <div key={section.title ?? `section-${index}`} className={index > 0 ? 'mt-4' : ''}>
            {section.title && !masquerLibellesDesktop && (
              <p className="px-3 pb-1 text-xs font-medium uppercase tracking-wider text-gray-400 dark:text-gray-500">
                {section.title}
              </p>
            )}
            <ul className="space-y-0.5">
              {section.items.map((item) => {
                const actif =
                  pathname === item.href || pathname.startsWith(`${item.href}/`);
                const Icon = item.icon;
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={closeMobile}
                      title={masquerLibellesDesktop ? item.label : undefined}
                      className={[
                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                        actif
                          ? 'bg-brand-50 text-brand-700 dark:bg-brand-600/10 dark:text-brand-200'
                          : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800',
                        masquerLibellesDesktop ? 'lg:justify-center lg:px-0' : '',
                      ].join(' ')}
                    >
                      <Icon className="h-5 w-5 shrink-0" />
                      <span className={masquerLibellesDesktop ? 'lg:hidden' : ''}>
                        {item.label}
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
