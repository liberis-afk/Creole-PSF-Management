'use client';

import { createContext, useCallback, useContext, useEffect, useState } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextValue {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

const STORAGE_KEY = 'psf-theme';

/**
 * Gère l'état du thème côté client et le synchronise avec la classe 'dark'
 * sur <html>. L'état INITIAL est lu depuis la classe déjà posée par le script
 * anti-flash (theme-script.ts) — ainsi le provider est d'emblée cohérent avec
 * ce que l'utilisateur voit, sans second rendu.
 */
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('light');

  useEffect(() => {
    // Au montage, on s'aligne sur la classe réellement présente (posée avant
    // l'hydratation par le script inline).
    const estSombre = document.documentElement.classList.contains('dark');
    setTheme(estSombre ? 'dark' : 'light');
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((precedent) => {
      const suivant: Theme = precedent === 'dark' ? 'light' : 'dark';
      const racine = document.documentElement;
      racine.classList.toggle('dark', suivant === 'dark');
      try {
        localStorage.setItem(STORAGE_KEY, suivant);
      } catch {
        // localStorage indisponible : le thème reste appliqué pour la session,
        // simplement non persisté. Dégradation acceptable.
      }
      return suivant;
    });
  }, []);

  return <ThemeContext.Provider value={{ theme, toggleTheme }}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme doit être utilisé à l’intérieur de <ThemeProvider>');
  }
  return context;
}
