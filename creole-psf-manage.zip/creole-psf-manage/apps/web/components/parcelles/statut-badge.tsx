import type { StatutParcelle } from '@/lib/parcelles-types';
import { LIBELLE_STATUT } from '@/lib/parcelles-types';

const COULEURS: Record<StatutParcelle, string> = {
  ACTIVE: 'bg-brand-50 text-brand-700 dark:bg-brand-600/10 dark:text-brand-200',
  EN_JACHERE: 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400',
  INACTIVE: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
};

export function StatutBadge({ statut }: { statut: StatutParcelle }) {
  return (
    <span className={`inline-block rounded-md px-2 py-0.5 text-xs font-medium ${COULEURS[statut]}`}>
      {LIBELLE_STATUT[statut]}
    </span>
  );
}
