'use client';

import { Search } from 'lucide-react';

interface FiltresProps {
  recherche: string;
  onRecherche: (v: string) => void;
  statut: string;
  onStatut: (v: string) => void;
  drainage: string;
  onDrainage: (v: string) => void;
}

const classeSelect =
  'rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 outline-none focus:border-brand-500 dark:border-gray-800 dark:bg-gray-950 dark:text-gray-200';

/**
 * Barre de filtres : recherche libre (debouncée dans le hook) + filtres statut
 * et drainage. Volontairement stateless — elle remonte tout au parent, qui
 * détient l'état via useParcellesList.
 */
export function ParcelleFiltres({
  recherche,
  onRecherche,
  statut,
  onStatut,
  drainage,
  onDrainage,
}: FiltresProps) {
  return (
    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
        <input
          type="search"
          value={recherche}
          onChange={(e) => onRecherche(e.target.value)}
          placeholder="Rechercher par nom, code, adresse…"
          className="w-full rounded-lg border border-gray-200 bg-white py-2 pl-9 pr-3 text-sm outline-none placeholder:text-gray-400 focus:border-brand-500 dark:border-gray-800 dark:bg-gray-950 dark:text-gray-100"
        />
      </div>

      <select value={statut} onChange={(e) => onStatut(e.target.value)} className={classeSelect} aria-label="Filtrer par statut">
        <option value="">Tous les statuts</option>
        <option value="ACTIVE">Active</option>
        <option value="EN_JACHERE">En jachère</option>
        <option value="INACTIVE">Inactive</option>
      </select>

      <select value={drainage} onChange={(e) => onDrainage(e.target.value)} className={classeSelect} aria-label="Filtrer par drainage">
        <option value="">Tout drainage</option>
        <option value="BON">Bon</option>
        <option value="MOYEN">Moyen</option>
        <option value="FAIBLE">Faible</option>
        <option value="STAGNANT">Stagnant</option>
      </select>
    </div>
  );
}
