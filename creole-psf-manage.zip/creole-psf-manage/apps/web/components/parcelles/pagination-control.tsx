'use client';

import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { Pagination } from '@/lib/parcelles-types';

/**
 * Pagination générique. Affiche la fenêtre courante et permet de naviguer.
 * Conçue pour être réutilisée par les futurs modules (cultures, employés…) —
 * elle ne dépend d'aucune donnée métier, juste de l'objet Pagination standard.
 */
export function PaginationControl({
  pagination,
  onPage,
  libelle = 'élément',
}: {
  pagination: Pagination;
  onPage: (page: number) => void;
  /** Nom de l'entité au singulier (le pluriel ajoute un 's'). */
  libelle?: string;
}) {
  const { page, totalPages, total } = pagination;
  if (total === 0) return null;

  return (
    <div className="flex items-center justify-between text-sm">
      <p className="text-gray-500 dark:text-gray-400">
        Page {page} sur {totalPages} · {total} {libelle}{total > 1 ? 's' : ''}
      </p>
      <div className="flex items-center gap-1">
        <button
          onClick={() => onPage(page - 1)}
          disabled={page <= 1}
          className="flex items-center gap-1 rounded-lg border border-gray-200 px-2.5 py-1.5 text-gray-600 hover:bg-gray-50 disabled:opacity-40 dark:border-gray-800 dark:text-gray-300 dark:hover:bg-gray-900"
        >
          <ChevronLeft className="h-4 w-4" />
          Précédent
        </button>
        <button
          onClick={() => onPage(page + 1)}
          disabled={page >= totalPages}
          className="flex items-center gap-1 rounded-lg border border-gray-200 px-2.5 py-1.5 text-gray-600 hover:bg-gray-50 disabled:opacity-40 dark:border-gray-800 dark:text-gray-300 dark:hover:bg-gray-900"
        >
          Suivant
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
