'use client';

import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import type { ParcelleCarte } from '@/lib/parcelles-types';

/**
 * Leaflet accède à `window` au chargement du module : il ne peut donc pas être
 * rendu côté serveur. On charge le composant carte en dynamique avec
 * ssr:false. Le wrapper récupère aussi les données côté client.
 *
 * ssr:false impose que ce wrapper soit lui-même un composant client (d'où
 * 'use client') — un composant serveur ne peut pas passer ssr:false.
 */
const ParcelleMapInner = dynamic(() => import('./parcelle-map-inner'), {
  ssr: false,
  loading: () => (
    <div className="flex h-[500px] items-center justify-center rounded-xl border border-gray-200 bg-gray-50 text-sm text-gray-400 dark:border-gray-800 dark:bg-gray-900">
      Chargement de la carte…
    </div>
  ),
});

export function ParcelleMap() {
  const [parcelles, setParcelles] = useState<ParcelleCarte[] | null>(null);
  const [erreur, setErreur] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/parcelles/carte', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then(setParcelles)
      .catch(() => setErreur('Impossible de charger la carte'));
  }, []);

  if (erreur) {
    return <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-600 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-400">{erreur}</div>;
  }

  if (!parcelles) {
    return (
      <div className="flex h-[500px] items-center justify-center rounded-xl border border-gray-200 bg-gray-50 text-sm text-gray-400 dark:border-gray-800 dark:bg-gray-900">
        Chargement…
      </div>
    );
  }

  const geolocalisees = parcelles.filter((p) => p.contour || p.centroide);

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 dark:border-gray-800">
      {geolocalisees.length === 0 && (
        <div className="border-b border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-700 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-400">
          Aucune parcelle géolocalisée pour l'instant. Ajoutez un point GPS ou un contour à vos parcelles pour les voir ici.
        </div>
      )}
      <ParcelleMapInner parcelles={parcelles} />
    </div>
  );
}
