'use client';

import { useEffect } from 'react';
import { MapContainer, TileLayer, Polygon, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { ParcelleCarte } from '@/lib/parcelles-types';

/**
 * Corrige le bug historique des icônes de marqueur Leaflet avec les bundlers :
 * les chemins d'images par défaut sont cassés. On pointe vers le CDN unpkg.
 * Exécuté une fois au chargement du module.
 */
const iconeDefaut = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const COULEUR_STATUT: Record<string, string> = {
  ACTIVE: '#15803d',
  EN_JACHERE: '#d97706',
  INACTIVE: '#6b7280',
};

/** Ajuste la vue pour englober toutes les parcelles présentes. */
function AjusterVue({ parcelles }: { parcelles: ParcelleCarte[] }) {
  const map = useMap();
  useEffect(() => {
    const points: L.LatLngExpression[] = [];
    for (const p of parcelles) {
      if (p.contour) {
        // GeoJSON est [lng, lat] ; Leaflet attend [lat, lng].
        for (const anneau of p.contour.coordinates) {
          for (const [lng, lat] of anneau) points.push([lat, lng]);
        }
      } else if (p.centroide) {
        const [lng, lat] = p.centroide.coordinates;
        points.push([lat, lng]);
      }
    }
    if (points.length > 0) {
      map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: 16 });
    }
  }, [parcelles, map]);
  return null;
}

export default function ParcelleMapInner({ parcelles }: { parcelles: ParcelleCarte[] }) {
  // Centre par défaut : Haïti (utilisé seulement si aucune parcelle géolocalisée).
  const centreParDefaut: L.LatLngExpression = [18.9712, -72.2852];

  return (
    <MapContainer center={centreParDefaut} zoom={8} className="h-full w-full" style={{ minHeight: 500 }}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <AjusterVue parcelles={parcelles} />

      {parcelles.map((p) => {
        const couleur = COULEUR_STATUT[p.statut] ?? '#6b7280';
        if (p.contour) {
          const positions = p.contour.coordinates.map((anneau) =>
            anneau.map(([lng, lat]) => [lat, lng] as L.LatLngExpression),
          );
          return (
            <Polygon key={p.id} positions={positions} pathOptions={{ color: couleur, fillOpacity: 0.2, weight: 2 }}>
              <Popup>
                <strong>{p.nom}</strong>
                <br />
                {p.code} · {p.superficieHa.toLocaleString('fr-FR')} ha
              </Popup>
            </Polygon>
          );
        }
        if (p.centroide) {
          const [lng, lat] = p.centroide.coordinates;
          return (
            <Marker key={p.id} position={[lat, lng]} icon={iconeDefaut}>
              <Popup>
                <strong>{p.nom}</strong>
                <br />
                {p.code} · {p.superficieHa.toLocaleString('fr-FR')} ha
              </Popup>
            </Marker>
          );
        }
        return null;
      })}
    </MapContainer>
  );
}
