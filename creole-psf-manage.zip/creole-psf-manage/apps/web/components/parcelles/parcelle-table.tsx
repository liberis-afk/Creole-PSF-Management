'use client';

import Link from 'next/link';
import { ArrowUpDown, MapPin } from 'lucide-react';
import type { ParcelleListItem } from '@/lib/parcelles-types';
import { LIBELLE_DRAINAGE } from '@/lib/parcelles-types';
import { StatutBadge } from './statut-badge';

interface TableProps {
  parcelles: ParcelleListItem[];
  chargement: boolean;
  tri: string;
  ordre: 'asc' | 'desc';
  onTri: (colonne: string) => void;
}

function EnteteTriable({ label, colonne, tri, ordre, onTri, align = 'left' }: { label: string; colonne: string; tri: string; ordre: string; onTri: (c: string) => void; align?: 'left' | 'right' }) {
  const actif = tri === colonne;
  return (
    <th className={`px-4 py-3 font-medium ${align === 'right' ? 'text-right' : 'text-left'}`}>
      <button onClick={() => onTri(colonne)} className={`inline-flex items-center gap-1 hover:text-gray-700 dark:hover:text-gray-200 ${actif ? 'text-gray-700 dark:text-gray-200' : ''}`}>
        {label}
        <ArrowUpDown className={`h-3 w-3 ${actif ? 'opacity-100' : 'opacity-40'}`} />
        {actif && <span className="text-xs">{ordre === 'asc' ? '↑' : '↓'}</span>}
      </button>
    </th>
  );
}

export function ParcelleTable({ parcelles, chargement, tri, ordre, onTri }: TableProps) {
  if (chargement) {
    return (
      <div className="space-y-2 rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-950">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-12 animate-pulse rounded bg-gray-50 dark:bg-gray-900" />
        ))}
      </div>
    );
  }

  if (parcelles.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-gray-300 bg-white py-16 text-center dark:border-gray-700 dark:bg-gray-950">
        <MapPin className="mx-auto h-8 w-8 text-gray-300 dark:text-gray-600" />
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Aucune parcelle ne correspond à ces critères.</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden overflow-x-auto rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-950">
      <table className="w-full text-sm">
        <thead className="border-b border-gray-100 text-xs text-gray-400 dark:border-gray-800 dark:text-gray-500">
          <tr>
            <EnteteTriable label="Nom" colonne="nom" tri={tri} ordre={ordre} onTri={onTri} />
            <EnteteTriable label="Code" colonne="code" tri={tri} ordre={ordre} onTri={onTri} />
            <EnteteTriable label="Superficie" colonne="superficieHa" tri={tri} ordre={ordre} onTri={onTri} align="right" />
            <th className="px-4 py-3 text-left font-medium">Type de sol</th>
            <th className="px-4 py-3 text-left font-medium">Drainage</th>
            <EnteteTriable label="Statut" colonne="statut" tri={tri} ordre={ordre} onTri={onTri} />
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
          {parcelles.map((p) => (
            <tr key={p.id} className="transition-colors hover:bg-gray-50 dark:hover:bg-gray-900">
              <td className="px-4 py-3">
                <Link href={`/parcelles/${p.id}`} className="font-medium text-gray-900 hover:text-brand-700 dark:text-white dark:hover:text-brand-200">
                  {p.nom}
                </Link>
                {(p.nbCultures > 0 || p.nbAnalyses > 0) && (
                  <p className="text-xs text-gray-400">
                    {p.nbCultures > 0 ? `${p.nbCultures} culture${p.nbCultures > 1 ? 's' : ''}` : ''}
                    {p.nbCultures > 0 && p.nbAnalyses > 0 ? ' · ' : ''}
                    {p.nbAnalyses > 0 ? `${p.nbAnalyses} analyse${p.nbAnalyses > 1 ? 's' : ''}` : ''}
                  </p>
                )}
              </td>
              <td className="px-4 py-3 font-mono text-xs text-gray-500 dark:text-gray-400">{p.code}</td>
              <td className="px-4 py-3 text-right text-gray-700 dark:text-gray-300">{p.superficieHa.toLocaleString('fr-FR')} ha</td>
              <td className="px-4 py-3 text-gray-500 dark:text-gray-400">{p.typeSol ?? '—'}</td>
              <td className="px-4 py-3 text-gray-500 dark:text-gray-400">{p.drainage ? LIBELLE_DRAINAGE[p.drainage] : '—'}</td>
              <td className="px-4 py-3"><StatutBadge statut={p.statut} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
