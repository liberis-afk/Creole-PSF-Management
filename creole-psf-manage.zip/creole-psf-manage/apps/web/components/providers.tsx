'use client';

import { ThemeProvider } from './theme-provider';
import { SidebarProvider } from './sidebar-provider';

/**
 * Regroupe les providers client. Le layout protégé (composant serveur) n'a
 * ainsi qu'UN composant client à monter, au lieu d'imbriquer manuellement
 * chaque provider — plus lisible et un seul endroit à modifier si on en
 * ajoute d'autres plus tard (ex. futur provider de permissions côté client).
 */
export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider>
      <SidebarProvider>{children}</SidebarProvider>
    </ThemeProvider>
  );
}
