'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronDown, LogOut, Moon, Sun, User } from 'lucide-react';
import { useTheme } from './theme-provider';

interface UserMenuProps {
  nomComplet: string;
  email: string;
  role: string;
}

/**
 * Menu déroulant du coin supérieur droit — pattern identique à Stripe :
 * avatar + nom, déroule profil / préférences / déconnexion.
 *
 * Ferme au clic extérieur et à la touche Échap (accessibilité). La
 * déconnexion réutilise la route BFF /api/auth/logout déjà en place —
 * aucune logique de token dupliquée ici.
 */
export function UserMenu({ nomComplet, email, role }: UserMenuProps) {
  const router = useRouter();
  const { theme, toggleTheme } = useTheme();
  const [ouvert, setOuvert] = useState(false);
  const [deconnexionEnCours, setDeconnexionEnCours] = useState(false);
  const conteneurRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ouvert) return;

    function surClicExterieur(e: MouseEvent) {
      if (conteneurRef.current && !conteneurRef.current.contains(e.target as Node)) {
        setOuvert(false);
      }
    }
    function surEchap(e: KeyboardEvent) {
      if (e.key === 'Escape') setOuvert(false);
    }

    document.addEventListener('mousedown', surClicExterieur);
    document.addEventListener('keydown', surEchap);
    return () => {
      document.removeEventListener('mousedown', surClicExterieur);
      document.removeEventListener('keydown', surEchap);
    };
  }, [ouvert]);

  async function seDeconnecter() {
    setDeconnexionEnCours(true);
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  }

  const initiales = nomComplet
    .split(' ')
    .map((partie) => partie.charAt(0))
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className="relative" ref={conteneurRef}>
      <button
        onClick={() => setOuvert((v) => !v)}
        className="flex items-center gap-2 rounded-lg p-1 pr-2 transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
        aria-haspopup="menu"
        aria-expanded={ouvert}
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-xs font-semibold text-white">
          {initiales}
        </span>
        <span className="hidden text-sm font-medium text-gray-700 dark:text-gray-200 sm:block">
          {nomComplet}
        </span>
        <ChevronDown className="h-4 w-4 text-gray-400" />
      </button>

      {ouvert && (
        <div
          role="menu"
          className="absolute right-0 mt-2 w-64 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-lg dark:border-gray-800 dark:bg-gray-900"
        >
          <div className="border-b border-gray-100 px-4 py-3 dark:border-gray-800">
            <p className="truncate text-sm font-medium text-gray-900 dark:text-white">
              {nomComplet}
            </p>
            <p className="truncate text-xs text-gray-500 dark:text-gray-400">{email}</p>
            <span className="mt-1 inline-block rounded-md bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700 dark:bg-brand-600/10 dark:text-brand-200">
              {role}
            </span>
          </div>

          <div className="py-1">
            <button
              role="menuitem"
              className="flex w-full items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              <User className="h-4 w-4" />
              Mon profil
            </button>

            <button
              role="menuitem"
              onClick={toggleTheme}
              className="flex w-full items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              {theme === 'dark' ? 'Thème clair' : 'Thème sombre'}
            </button>
          </div>

          <div className="border-t border-gray-100 py-1 dark:border-gray-800">
            <button
              role="menuitem"
              onClick={seDeconnecter}
              disabled={deconnexionEnCours}
              className="flex w-full items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 disabled:opacity-50 dark:text-red-400 dark:hover:bg-red-500/10"
            >
              <LogOut className="h-4 w-4" />
              {deconnexionEnCours ? 'Déconnexion…' : 'Se déconnecter'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
