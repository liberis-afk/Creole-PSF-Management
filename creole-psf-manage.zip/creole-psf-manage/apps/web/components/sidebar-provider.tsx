'use client';

import { createContext, useCallback, useContext, useEffect, useState } from 'react';

interface SidebarContextValue {
  /** Desktop : sidebar réduite aux icônes. */
  collapsed: boolean;
  toggleCollapsed: () => void;
  /** Mobile : tiroir ouvert par-dessus le contenu. */
  mobileOpen: boolean;
  openMobile: () => void;
  closeMobile: () => void;
}

const SidebarContext = createContext<SidebarContextValue | null>(null);

const STORAGE_KEY = 'psf-sidebar-collapsed';

/**
 * Sépare volontairement DEUX états car ce sont deux comportements distincts :
 *   - `collapsed` (desktop) : la sidebar reste visible mais réduite aux
 *     icônes ; préférence persistée entre sessions.
 *   - `mobileOpen` (mobile) : la sidebar est un tiroir superposé, jamais
 *     persisté (on ne rouvre pas un tiroir au rechargement).
 * Les mélanger dans un seul booléen créerait des incohérences au passage
 * desktop <-> mobile.
 */
export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    try {
      setCollapsed(localStorage.getItem(STORAGE_KEY) === 'true');
    } catch {
      // ignore
    }
  }, []);

  const toggleCollapsed = useCallback(() => {
    setCollapsed((precedent) => {
      const suivant = !precedent;
      try {
        localStorage.setItem(STORAGE_KEY, String(suivant));
      } catch {
        // ignore
      }
      return suivant;
    });
  }, []);

  const openMobile = useCallback(() => setMobileOpen(true), []);
  const closeMobile = useCallback(() => setMobileOpen(false), []);

  return (
    <SidebarContext.Provider
      value={{ collapsed, toggleCollapsed, mobileOpen, openMobile, closeMobile }}
    >
      {children}
    </SidebarContext.Provider>
  );
}

export function useSidebar(): SidebarContextValue {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error('useSidebar doit être utilisé à l’intérieur de <SidebarProvider>');
  }
  return context;
}
