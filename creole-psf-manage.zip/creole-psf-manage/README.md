# Creole PSF Manage

Plateforme SaaS professionnelle de gestion d'exploitations agricoles —
multi-fermes, multi-utilisateurs, pensée pour les réalités des pays en
développement (hors ligne différé, irrigation variée, extensible).

Ce dépôt est un **monorepo** :

```
creole-psf-manage/
├── apps/
│   ├── api/     API REST — NestJS + Prisma + PostgreSQL/PostGIS
│   └── web/     Interface — Next.js (App Router) + React + Tailwind
├── docker-compose.yml   Base PostgreSQL/PostGIS de développement
├── TESTING.md           Comment lancer les tests (4 couches)
└── docs/                Documentation détaillée (ci-dessous)
```

## Lancer dans GitHub Codespaces (recommandé, sans installation locale)

Le dépôt inclut une configuration `.devcontainer/` : à l'ouverture d'un
Codespace, Node.js, PostgreSQL/PostGIS, Prisma et toutes les dépendances
s'installent **automatiquement**, le schéma est créé et les données de démo
chargées. Il ne reste qu'une commande à lancer :

```bash
npm run dev
```

Idéal depuis un Chromebook ou toute machine sans environnement Linux. Marche à
suivre complète (import du ZIP compris) : **[GITHUB-CODESPACES.md](GITHUB-CODESPACES.md)**.

## Documentation

| Document | Contenu |
|----------|---------|
| [docs/01-installation.md](docs/01-installation.md) | Prérequis, mise en place locale, base de données, premier démarrage |
| [docs/02-configuration.md](docs/02-configuration.md) | Toutes les variables d'environnement et fichiers de configuration |
| [docs/03-deploiement.md](docs/03-deploiement.md) | Mise en production, Docker, migrations, durcissement sécurité |
| [docs/04-utilisation.md](docs/04-utilisation.md) | Prise en main fonctionnelle, rôles, modules |
| [docs/05-api.md](docs/05-api.md) | Conventions REST, authentification, Swagger, endpoints |
| [docs/06-architecture.md](docs/06-architecture.md) | Architecture technique, patterns, base de données, décisions |
| [TESTING.md](TESTING.md) | Suite de tests et exécution |

## État d'avancement des modules

La SFD définit 17 modules (10 prioritaires pour le MVP). Sont **livrés** à ce
jour :

| # | Module | État |
|---|--------|------|
| 1 | Authentification / RBAC / Journal de sécurité | ✅ |
| 2 | Tableau de bord | ✅ |
| 3 | Parcelles (+ cartographie Leaflet) | ✅ |
| 4 | Cultures | ✅ |
| 5 | Calendrier agricole (activités) | ✅ |
| 7 | Équipements & maintenance | ✅ |
| 6, 8–17 | Employés, Stocks, Finances, Irrigation, Récoltes, Ventes, Documents, Rapports, Cartographie avancée, Notifications, Paramètres | ⏳ à venir |

La base de données (schéma Prisma, ~47 tables) est en revanche **déjà complète**
pour l'ensemble des modules : les modules à venir s'appuieront sur des tables
existantes.

## Démarrage express

```bash
# 1. Base de données
docker compose up -d

# 2. API
cd apps/api
cp .env.example .env
npm install
npx prisma migrate dev
npx prisma db seed
npm run start:dev        # http://localhost:3001/api/v1 — Swagger : /api/docs

# 3. Interface (autre terminal)
cd apps/web
cp .env.example .env.local
npm install
npm run dev              # http://localhost:3000
```

Détails complets dans [docs/01-installation.md](docs/01-installation.md).
