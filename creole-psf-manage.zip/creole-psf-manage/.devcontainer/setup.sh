#!/usr/bin/env bash
#
# Installation automatique exécutée par Codespaces à la création du conteneur
# (postCreateCommand). À la fin, il ne reste plus qu'à lancer : npm run dev
#
set -euo pipefail

echo "▶ [1/5] Fichiers d'environnement..."
if [ ! -f apps/api/.env ]; then
  cp apps/api/.env.example apps/api/.env
  # Dans Codespaces, la base se joint par le nom de service "postgres".
  sed -i 's#@localhost:5432#@postgres:5432#' apps/api/.env
fi
if [ ! -f apps/web/.env.local ]; then
  cp apps/web/.env.example apps/web/.env.local
fi

echo "▶ [2/5] Installation des dépendances (api + web)..."
npm install

echo "▶ [3/5] Génération du client Prisma..."
npm run prisma:generate

echo "▶ [4/5] Création du schéma en base (PostGIS déjà activé par l'image)..."
# Pas de dossier de migrations : on pousse directement le schéma.
( cd apps/api && npx prisma db push )

echo "▶ [5/5] Données initiales (rôles, permissions, admin, permissions par module)..."
npm run prisma:seed
( cd apps/api \
  && npx ts-node prisma/seeds/parcelles-permissions.seed.ts \
  && npx ts-node prisma/seeds/cultures-permissions.seed.ts \
  && npx ts-node prisma/seeds/equipements-permissions.seed.ts \
  && npx ts-node prisma/seeds/activites-permissions.seed.ts )

echo ""
echo "✅ Environnement prêt."
echo "   Lancez l'application avec :  npm run dev"
echo "   Interface : port 3000   |   API : port 3001   |   Swagger : /api/docs"
echo "   Connexion de démo : admin@creolepsf.ht / ChangeMoi123!"
